# Modular Desk Organizer

Practice folder recreated from the visible folder name in the screenshot.
Includes a simple valid ASCII STL box model and a small parts list for Python file-handling exercises.
