# Floating Corner Shelf

Practice folder recreated from the screenshot. Contains a basic ASCII STL placeholder and a dimensions CSV.
