# Django Project README Template

This sample Markdown file is recreated from the visible filename in the screenshot.

## Setup

```bash
python -m venv .venv
pip install -r requirements.txt
python manage.py runserver
```

## Notes

- Replace example settings before deployment.
- Keep environment variables out of version control.
