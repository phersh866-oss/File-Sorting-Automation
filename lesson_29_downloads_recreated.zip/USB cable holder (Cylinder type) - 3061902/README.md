# USB Cable Holder (Cylinder Type)

Practice folder recreated from the screenshot. The STL is a simple valid ASCII geometry placeholder.
