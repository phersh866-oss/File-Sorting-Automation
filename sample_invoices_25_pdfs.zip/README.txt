Sample Invoice PDFs
===================
This folder contains 25 valid, fictional PDF invoices generated for programming and document-processing tests.
All business names, contacts, addresses, dates, and invoice details are synthetic.
A CSV manifest is included for convenient testing.
